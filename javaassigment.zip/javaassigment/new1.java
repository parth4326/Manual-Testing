package javaassigment;

public class new1 {

}
