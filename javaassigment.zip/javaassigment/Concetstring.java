package javaassigment;

public class Concetstring {
public static void main(String[] args) 
{
	  String line1 = " my name is" ;
	  String line2 = " manisha " ;
	  
	  System.out.println(" String1 = " +line1 );
	  System.out.println(" String2 = " +line2 );
	  
	  String line3 = line1.concat(line2)  ;
	   
	  System.out.println(" concaneted String is = " +line3 );
}
}
