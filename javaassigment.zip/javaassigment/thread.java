package javaassigment;

public class thread {

}
