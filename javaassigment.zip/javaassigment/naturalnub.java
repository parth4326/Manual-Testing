package javaassigment;

public class naturalnub {


	
	public static void main(String[] args) {
		
		System.out.println("the first 10 natural nub is : ");
		
		for(int i = 1 ; i<=10 ; i++)
		{
			System.out.println(i);
		}
		System.out.println();
	}
}




